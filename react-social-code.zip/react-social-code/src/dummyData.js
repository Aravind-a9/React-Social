export const Users = [
    {
        id: 1,
        profilePicture: "assets/persons/1.jfif",
        userName: "Kathy"
    },
    {
        id: 2,
        profilePicture: "assets/persons/2.jfif",
        userName: "Nathasha"
    },
    {
        id: 3,
        profilePicture: "assets/persons/3.jfif",
        userName: "Vincent"
    },
    {
        id: 4,
        profilePicture: "assets/persons/4.jpg",
        userName: "Jake Sully"
    },
    {
        id: 5,
        profilePicture: "assets/persons/5.jfif",
        userName: "John Carter"
    },
    {
        id: 6,
        profilePicture: "assets/persons/6.jfif",
        userName: "Bruce"
    },
    {
        id: 7,
        profilePicture: "assets/persons/7.jfif",
        userName: "Nytiri"
    },
    {
        id: 8,
        profilePicture: "assets/persons/8.jfif",
        userName: "Anna"
    }
];

export const Posts = [
    {
        id: 1,
        desc: "My new Car!!",
        photo: "assets/posts/car.jfif",
        date: "2min ago",
        userId: 1,
        like: 23,
        comment:8
    },
    
    {
        id: 2,
        desc: "New thrill with new Bike",
        photo: "assets/posts/bike.jpg",
        date: "14min ago",
        userId: 2,
        like: 29,
        comment:4
    },
    {
        id: 3,
        desc: "peaceful life in peaceful world",
        photo: "assets/posts/dolphine.jfif",
        date: "20min ago",
        userId: 8,
        like: 231,
        comment:83
    },
    {
        id: 4,
        desc: "i love my country!!",
        photo: "assets/posts/flag.jfif",
        date: "25min ago",
        userId: 8,
        like: 233,
        comment:18
    },
    {
        id: 5,
        desc: "Ma Jake",
        photo: "assets/posts/majake.jpg",
        date: "6min ago",
        userId: 7,
        like: 32,
        comment:6
    },
    {
        id: 6,
        desc: "Super Star",
        photo: "assets/posts/Rajini.jfif",
        date: "8min ago",
        userId: 6,
        like: 23,
        comment:8
    },
    {
        id: 7,
        desc: "Sully stick together.",
        photo: "assets/posts/avatar.jfif",
        date: "10 years ago",
        userId: 4,
        like: 2323,
        comment:823
    },
]