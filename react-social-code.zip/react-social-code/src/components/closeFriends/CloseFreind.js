import "./closefriend.css"

export default function CloseFreind({user}) {
  return (
      <div>
           <li className="sidebarFriend">
            <img src={user.profilePicture} alt="" className="sidebarFriendImg" />
              <span className="sidebarFriendName">{user.userName}</span>
          </li>
          
      </div>
  )
}
